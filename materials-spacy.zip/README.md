# Natural Language Processing With spaCy in Python

Corresponding code for the Real Python tutorial [Natural Language Processing With spaCy in Python](https://realpython.com/natural-language-processing-spacy-python/)

All the examples from the tutorial have been combined into one file. For the best experience, use VS Code with the [Jupyter extension](https://marketplace.visualstudio.com/items?itemName=ms-toolsai.jupyter). This uses the `# %%` token as a delimiter for separate cells, allowing you to run cells one by one and inspect the output.
